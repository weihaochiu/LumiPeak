# PL Studio

[繁體中文](README.md) | [English](README.en.md)

[Requirements and verification log (Traditional Chinese)](docs/需求紀錄.md)

**Steady-state photoluminescence analysis for Windows | Traditional Chinese / English | Version 0.5.0**

### [⬇ Download for Windows](https://github.com/weihaochiu/LumiPeak/releases/latest/download/PL-Studio-Setup.exe)

Installers are built by GitHub Actions and become available when the Release is published.

Windows 10 / 11, x64. Download `PL-Studio-Setup.exe`, run the installation wizard, then launch PL Studio from the Start menu or desktop shortcut. The installer includes Python and the required libraries.

## Language and updates

- Choose **Settings → 語言 / Language → English** or **繁體中文**. The interface changes immediately and remembers your choice. On first launch, Chinese Windows uses Traditional Chinese; other system languages use English.
- Startup checks run in the background against the latest stable GitHub Release. A newer release offers **Download update**, **Remind me later** and **Skip this version**.
- Use **Settings → Check for updates now** for a manual check, or disable startup checks. Manual checks also show versions you previously skipped.
- Offline access and failed checks do not interrupt analysis. Checks fetch public release information and never upload spectra or project data.
- Save your project and close PL Studio before running the downloaded installer. See [Releases](https://github.com/weihaochiu/LumiPeak/releases) for release notes.

## Features

- Import two-column wavelength (nm) / intensity text files: TXT, CSV, DAT, TSV and ZIP. Instrument metadata is retained. Drag and drop is supported.
- Fit Gaussian, Lorentzian, Voigt, PseudoVoigt, SkewedGaussian and SkewedVoigt peaks, with constant, linear or no background. Supports bounds, fixed parameters and lmfit parameter expressions.
- Single-spectrum, batch and joint fits with selected shared parameters. Peak-finding smoothing never changes the data used for fitting.
- Compare raw and independently normalized PL overlays, and parameter-versus-Condition trends with dot, line, dot-line, bar and area plots.
- A dedicated **Figure Template** window controls page layout, axes, ticks, grids, markers, legends, insets, annotations and export settings independently for each plot type.
- Export PNG, JPEG, PDF, SVG, Excel, an Origin CSV / script bundle, and optional `.opju` files through a licensed Origin installation and compatible `originpro`.
- Self-contained `.plproj` projects store raw files, metadata, settings, results and fit history. Recovery snapshots are created every minute while there are unsaved changes.

## Basic workflow

1. Create a project and import spectra with at least 10 numeric rows. Input wavelengths must be positive, finite and unique.
2. Edit display names on the left. Checkboxes control overlays, trends and figure exports; Ctrl / Shift selection controls batch operations. These are separate selections.
3. Choose fitting coordinates, range, exclusions, background and peak models. Shift-drag selects a range in the main plot.
4. Edit initial values, bounds, fixed parameters and expressions. Parameter expressions constrain existing model parameters; they do not define arbitrary peak functions.
5. Fit the current spectrum, batch fit selected spectra with their own settings, or joint fit with the current configuration and checked shared parameters.
6. Inspect residuals, convergence, uncertainty and warnings. Refit after changing working settings; existing results retain the configuration used to produce them.
7. Enter a Condition for each spectrum to compare fitted metrics. Conditions may be names or finite numbers; no replicate averaging or group statistics are performed.
8. Use Figure Template for presentation settings, export results and save the complete project.

**Peak intensity** is the fitted component's maximum, excluding background and other peaks. It differs from peak area. Peak identifiers follow the order of components in each fit; users must verify that compared peaks represent the same physical feature.

## Definitions and scientific limits

- Instrument Counts are not calibrated photon flux. Energy uses `E = 1239.8419843320026 / wavelength_nm`. The optional Jacobian is valid only when the input is spectral density per nm; Counts/pixel must not be treated as per nm automatically.
- Normalization uses the full measured spectrum before cropping to the fitting range. Display-only normalization and offsets do not change fitted data.
- Fits use unweighted least squares with deterministic initial-value retries. Standard errors are local covariance estimates, not replicate statistics. Unidentifiable or unavailable errors remain blank.
- Model center, numerical peak maximum and spectral centroid are different quantities. FWHM is unavailable if either half-maximum crossing lies outside the fit range. Model areas are integrated over the full fit interval, including excluded intervals; measured integration and centroid are not reported across masked gaps.
- Trend comparisons require compatible coordinates and intensity processing. Different integration ranges produce notices. Only already available parameter standard errors are plotted; FWHM or peak-position errors are not invented.
- AIC / BIC comparisons require the same data and assumptions. Joint-fit information criteria and degrees of freedom describe the entire joint fit.
- Peak decomposition alone does not establish excitonic, defect or phase assignments. A single uncalibrated PL spectrum does not determine lifetime, defect density, PLQY or QFLS. Finite-range area is not PLQY.
- Origin exports currently transfer data and basic curves, without reproducing all Figure Template styles. Direct `.opju` automation requires a separate compatible Origin installation and has not been validated on this computer.

## Run from source

Install Python 3.11+ (3.12 recommended), then run `INSTALL.bat` followed by `START_PL.bat`. Alternatively:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe main.py
```

`START_DEMO.bat` opens a local demo, generating synthetic spectra if no reference demo exists. Private experimental data and derived local reports are excluded from the public source release.

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements-build.txt
.\.venv\Scripts\python.exe -m pytest tests -q
```

Recovery files for named projects are stored beside the project as `.plproj.recovery`. Untitled recovery files are stored under `%LOCALAPPDATA%\PLStudio\PL Studio\PL_unsaved.recovery`. Startup errors are recorded in `%LOCALAPPDATA%\PLStudio\PL_error.log`. Recovery does not replace manual saves.

## Build and publish

See [the release guide](docs/RELEASING.md). Configure the repository before distributing a build, install Inno Setup 6+, and run:

```powershell
.\.venv\Scripts\python.exe tools/configure_release.py --repository YOUR_NAME/PL-Studio
powershell -ExecutionPolicy Bypass -File tools/build_windows.ps1
```

The installer is written to `release/PL-Studio-Setup.exe`. Publishing a new version on `main`, or pushing a matching version tag, runs tests and publishes the installer through GitHub Actions. Existing release assets are preserved. Manual workflow runs produce a build artifact without creating a release.

No source license has been selected yet. Choose license terms before publishing for reuse.
