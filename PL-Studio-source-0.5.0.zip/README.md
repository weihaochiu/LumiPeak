# PL Studio

[繁體中文](README.md) | [English](README.en.md)

[需求與驗證紀錄](docs/需求紀錄.md)

**Windows 穩態光致發光（PL）分析軟體｜繁體中文／English｜目前版本 0.5.0**

### [⬇ 下載 Windows 安裝版](https://github.com/weihaochiu/LumiPeak/releases/latest/download/PL-Studio-Setup.exe)

<!-- DOWNLOAD_STATUS -->安裝檔由 GitHub Actions 建置，請在 Release 發佈完成後下載。<!-- /DOWNLOAD_STATUS -->

安裝版適用於 Windows 10／11（x64），不需要另外安裝 Python。下載 `PL-Studio-Setup.exe`，依安裝精靈完成安裝，再從開始功能表或桌面捷徑開啟。

## 語言與版本更新

- 同一套軟體可在「**設定 → 語言 / Language**」切換繁體中文／English，立即生效並記住選擇；初次啟動依 Windows 語言判斷，其他語言預設英文。
- 預設啟動後在背景檢查 GitHub 最新正式版；有新版時提供「下載更新／稍後提醒／略過此版本」。手動檢查不受略過設定影響。
- 可在「設定」關閉啟動檢查，或使用「立即檢查更新」；離線、逾時與檢查失敗不影響分析。
- 更新檢查僅向 GitHub 取得公開版本資訊，不上傳光譜或專案資料。點擊下載後請先儲存專案、關閉軟體，再執行安裝檔。
- 最新版本與更新摘要可在 [Releases](https://github.com/weihaochiu/LumiPeak/releases) 查看。

以 Python、PySide6、Matplotlib、lmfit 製作的穩態 PL 桌面分析程式。第一版以鈣鈦礦薄膜的雙欄光譜為使用情境，**每條資料獨立管理，不含 Condition 分組或重複量測統計**。

## 從原始碼執行（開發用途）

先安裝 Python 3.11 或以上（建議 3.12），雙擊 `INSTALL.bat` 建立環境並下載依賴；完成後雙擊 **`START_PL.bat`** 啟動。安裝版使用者不需要這些步驟。

雙擊 **`START_DEMO.bat`** 可開啟本機示範專案；若沒有示範檔，會先產生合成光譜。私人量測資料與衍生圖表不包含在公開原始碼中。合成資料用於操作驗證，不代表特定材料的物理模型。

或在本目錄的 PowerShell 執行：

```powershell
.\.venv\Scripts\python.exe main.py
```

首次移至其他電腦時，請安裝 Python 3.11 或以上（建議 3.12），再雙擊 `INSTALL.bat` 安裝本專案環境。`.venv` 不應直接複製到其他電腦；請重新安裝。安裝需要網路。

## 使用流程

1. 新增專案，匯入 TXT / CSV / DAT / TSV 或 ZIP，也可直接拖曳。單檔需為**波長 nm、強度 Counts**兩欄，無千分位符號。支援 Tab、空白、逗號或分號分隔；數值後的儀器資訊會保留。多光譜矩陣、Excel 原始檔、儀器二進位檔尚不支援。
2. 左側可雙擊「使用者定義名稱」或按 F2 直接改名，也可在下方名稱欄輸入後按 Enter。名稱同步用於 PL 疊圖圖例、趨勢資料名稱與標註；Condition 留白時也使用此名稱。原始檔名另行顯示且保持不變。Ctrl / Shift 可多選供批次擬合；左側**勾選**同步控制圖形輸出、參數趨勢圖與 PL 疊圖。上移／下移會同步改變原始強度及 Normalized 疊圖的線條／圖例順序，以及類別趨勢圖的 X 軸順序。數值趨勢若啟用由小到大排序，仍依 Condition 數值排列。名稱、勾選與上下順序隨專案保存。
3. 設定擬合座標與區間。主圖按住 Shift 拖曳可選區；遮罩格式為 `750:755; 850:852`，單位依目前座標。數值欄也可手動輸入。
4. 選擇 Gaussian、Lorentzian、Voigt、PseudoVoigt、SkewedGaussian 或 SkewedVoigt；可新增、移除或替換分峰，背景可選常數、線性或無背景。
5. 雙擊參數表編輯初始值、上下限；勾選固定，或輸入 lmfit 參數關係式。例如 `p2_center` 的關係式填 `p1_center + 5`。不能以這個欄位定義任意新峰形；這是參數約束。
6. 自動找峰產生候選峰，使用者仍需確認物理合理性。Savitzky–Golay 只用於找峰，**擬合始終使用未平滑資料**。
7. 「擬合目前光譜」處理當前資料。「批次擬合選取光譜」使用各光譜自己的設定；要統一設定，先按「套用目前設定至選取光譜」。
8. 聯合擬合：先在參數表「共用」欄勾選參數，再多選光譜執行。**所選資料會共用目前光譜的模型、區間與初始設定**，勾選參數綁定成同一值，其餘參數獨立擬合。共用參數不可同時固定或指定關係式。
9. 檢查總擬合、各分峰、背景、殘差與結果表。表格可排序並用 Ctrl+C 複製。修改工作設定後，舊結果仍代表原本的模型；請重新擬合更新。切換座標時不會把舊座標的擬合線疊到新座標上。
10. 再次擬合會把舊結果存入歷史；雙擊歷史紀錄可還原。所有版本均保存在專案中。
11. 點上方工具列 **Figure Template**（Ctrl+T），在獨立視窗中分別設定光譜／擬合圖、PL 疊圖、參數趨勢圖的版面並預覽。可套用單一圖型、套用全部圖型，或儲存／載入 JSON 設定檔。
12. 儲存 `.plproj` 專案，內含原始檔案、儀器資訊、擬合結果與歷史、作圖設定，無需依賴原始檔案的外部路徑。

## Condition 參數趨勢圖（0.2 版）

切換主畫面 **「參數趨勢圖」**，可快速查看 X 軸為 Condition、Y 軸為擬合結果的多張圖。預設同時顯示峰頂位置、FWHM、分峰區間面積、**Peak intensity**；也可使用「顯示方式」切換任意單一指標。

**Peak intensity 定義為所選擬合分峰的峰頂強度，不包含背景或其他分峰。** 未歸一化的 nm 光譜以 Counts 顯示，經歸一化則為 a.u.；其定義與峰面積不同。UI 分峰表及總覽表均顯示此數值，一般 Excel 增加 `peak_intensity`／`peak_1_intensity` 欄位。內部仍保留 `height` 鍵，既有專案無需重新擬合即可查看。開啟舊專案時若總覽只勾選三個指標，可勾選 Peak intensity，或按「快速恢復：峰頂位置 + FWHM + 面積 + 強度」。

1. 在右側 Condition 表中，雙擊填入每條資料的 Condition。可填 `Control` / `Treatment` 等名稱，或 `20` / `100` 等數字；留白使用顯示名稱。這些欄位與原始檔名分開保存。
2. 勾選要分析的光譜。趨勢表與左側勾選**雙向同步**，取消任一側勾選會立即從趨勢圖、數值表和疊圖移除；同 Condition 的多條資料各是一個點，不做平均或誤差統計。類別順序依左側資料順序，可用上移／下移調整。
3. 選擇類別、數值或自動 Condition 座標。數值模式要求有限的純數字，單位請填入 X 軸標籤，例如 `Annealing temperature (°C)`；可由小到大排序。
4. 選擇分析的 Peak 編號。程式依各次擬合的峰編號取值，不會自行判斷不同光譜的 Peak 1 是否有相同物理來源。
5. 總覽可勾選峰頂位置、模型中心、FWHM、區間面積、模型總面積參數、Peak intensity（扣背景峰高）、面積比例、RMSE、R²、光譜重心及實測扣背景積分；不適用的選項會反灰並顯示原因。
6. 可顯示資料名稱、連線與已有的模型中心／面積參數標準誤。其餘項目沒有已保存且定義一致的標準誤時，不自行推算誤差棒。預設排除未收斂結果；可由使用者明確納入。
   圖型選單提供 **Dot、Line、Dot-Line、Bar、Area**，圖型也會隨專案及 Figure Template 保存。
7. 下方 **「趨勢數值」** 表同步顯示 Condition、資料、指標、數值、單位、可用標準誤與狀態。未擬合、缺少該 Peak 或無法取得 FWHM 等情形會列出原因。
8. 可匯出目前總覽／單圖（PNG、JPG、PDF、SVG），或將勾選指標分別匯出成多張圖。趨勢 Excel 匯出所有勾選指標，含無效數值原因、擬合版本與設定。一般結果 Excel 也增加 Condition 欄位。
9. Condition、共用作圖勾選與趨勢設定隨專案保存；舊專案可以開啟，未填 Condition 時使用顯示名稱。舊專案若左右勾選曾經不同，0.3 版以左側勾選為準並同步。

趨勢一律使用**已保存擬合結果**，不會因工作區設定尚未重新擬合就改變數值或單位。不同座標／Jacobian 定義的峰位與寬度不能混畫；不同強度處理的面積與峰高不能混畫。有限區間積分範圍不同時會顯示比較提示。第一版的區間面積不是 PLQY。

已開啟的舊版視窗不會自動更新程式碼；請先儲存專案，再關閉視窗並重新啟動。

## 選取光譜 PL 疊圖（0.3 版）

切到 **「PL 疊圖」**，立即疊上所有左側勾選的光譜；不需要先擬合。

- X 軸固定為原始**波長 nm**，使用完整量測範圍，不沿用擬合區間或能量座標。
- 預設**同時顯示兩張疊圖**：上方為原始值 Intensity（Counts），下方為 Normalized intensity（I / Imax）。也可切換只預覽其中一種。
- 原始值直接顯示儀器數值，不受擬合時的歸一化設定影響。Counts 尚未代表絕對校正的光子通量。
- Normalized 將每條光譜各自除以其完整量測範圍內的最大強度，峰值為 1；不扣背景、不做平滑、不修改原始資料。最大強度非正值的光譜無法使用這種歸一化。
- 可調整顯示波長範圍、標題、圖例、字級、線寬、尺寸與 DPI，匯出 PNG、JPG、PDF 或 SVG。
- **輸出內容可獨立選擇**：只輸出原始值、只輸出 Normalized、兩者合成同一張、兩者分別輸出兩張，或依目前預覽。預設分別輸出兩張，檔名加上 `_intensity` 與 `_normalized`。輸出選項不會改動畫面預覽。
- 勾選與趨勢圖及圖形輸出共用；取消勾選 C3 時，圖線、圖例與趨勢資料點均立即移除。滑鼠選取的反白列供分析／批次操作，與作圖勾選不同。
- 疊圖的 Y 軸模式與版面設定會隨專案保存；「匯出圖片」會依目前所在工作頁匯出相應圖形。

## Figure Template（0.4 版）

主畫面保留「光譜分析、參數趨勢圖、PL 疊圖」三個工作頁；原「論文作圖」改為上方 **Figure Template** 獨立視窗。格式設計參考 Origin 官方 [Customizing Graphs](https://docs.originlab.com/user-guide/customizing-graphs/) 的 Page / Layer / Plot / Axis 組織方式。

每個圖型各自保留設定，在下拉選單切換時不會混用另一種圖的設定。左側為預覽，右側分頁提供：

| 分頁 | 已提供的設定 |
|---|---|
| 基本／內容 | 圖寬高、DPI、字型、基本字級、線寬、標題、座標標籤、範圍、圖例、格線 |
| 圖型專用 | 光譜／總擬合／分峰／背景／殘差；疊圖原始／Normalized／同時顯示及輸出選擇；趨勢 Dot、Line、Dot-Line、Bar、Area、指標、Peak 編號、誤差棒 |
| 頁面／圖層 | 直橫向、頁面及繪圖區背景、自動或手動邊界、面板欄數、水平及垂直間距、面板編號與位置 |
| 座標軸 | Linear / Log / Symlog、反向、上／右軸、軸線色與寬度、標題及刻度字級、粗體、文字顏色、標籤距離 |
| 刻度／格線 | 主／次刻度、刻度長度線寬與方向、主刻度間隔或數目、指定刻度值、小數／科學記號、標籤旋轉、主次格線樣式 |
| 線條／符號 | 配色、線型、不透明度、符號形狀／大小／填色／邊色、長條邊線與填紋、誤差棒寬度及端帽 |
| 圖例 | 位置、欄數、邊框、背景、透明度、字級、圖例標題、反序、圖外圖例、列間距 |
| 參考線／Inset | 水平／垂直參考線、局部放大圖、指定來源面板、位置、放大範圍及連接線 |
| 文字／箭頭 | 以表格新增文字或箭頭，設定面板、資料／圖層比例座標、顏色及字級 |
| 形狀 | 矩形／橢圓、大小位置、填色、邊色、不透明度 |
| 各面板覆寫 | 指定面板的 X/Y 範圍、標題、座標標籤與位置矩形 |
| 輸出 | 透明背景、依內容裁切、留白、JPEG 品質 |

「套用此圖設定」只套用選取的圖型；「套用全部圖型設定」套用各圖型自己已設定的值。模板不包含原始資料或擬合結果，也不改動左側資料勾選。

設定檔為 `PLStudioPlotStyle` version 2 的 JSON，包含三種圖型的設定；可載入舊版 version 1 樣式檔。套用後的值也隨 `.plproj` 保存。預設保留輸出實際 cm 尺寸；啟用「裁切至內容」會使成品尺寸隨內容改變。多面板的不同量綱 Y 軸範圍請在「各面板覆寫」設定，通用 Y 範圍只作用於單面板。類別 Condition 不支援對數軸。

此處是 **PL 二維圖形的設定實作**，不等於完整複製 Origin 所有圖型與功能；Origin 的 3D、極座標、三元圖、地圖、日期軸、腳本連結物件及斷軸等目前未提供。Origin 原生 `.otp/.otpu` 模板不能直接當成本程式的 JSON 模板載入。

**Origin 相容性：Figure Template 可套用到本程式的預覽與 PNG/JPG/PDF/SVG 輸出；目前 `.opju` 與 Origin 資料包的腳本仍未逐項轉換這些版面設定，因此在 Origin 開啟後不保證外觀相同。** 本機未找到可供實測的 Origin 安裝，不能宣稱已驗證可編輯樣式同步。

## 作圖選項的適用性

主畫面趨勢圖及 Figure Template 使用同一套判斷：

- 對稱模型（Gaussian、Lorentzian、Voigt、PseudoVoigt）使用「峰頂位置」；「模型中心」反灰並註明與峰頂相同。含 SkewedGaussian／SkewedVoigt 時才開放模型中心；混用時會標註。
- 「分峰面積比例」只在所選 Peak 所屬的擬合包含至少兩個峰時開放。混合單峰與多峰結果時，此指標排除單峰資料並記錄原因，其他指標仍可比較。
- 判斷依作圖勾選、Peak 編號、是否納入未收斂結果及已保存的擬合版本更新；尚未擬合的資料參考工作設定。舊專案若選取已不適用的模型中心，改用峰頂位置；不適用的比例選項取消勾選，不改動擬合結果。
- Figure Template 沒有擬合結果時停用總擬合線與殘差；沒有多峰結果時停用分峰線；沒有背景模型時停用背景線。只有已有標準誤的指標可操作誤差棒。
- 長條圖才開放長條樣式，長條圖的曲線符號設定反灰；類別 Condition 停用數值刻度與對數尺度。局部放大、面板編號、次刻度、圖例、手動版面及裁切留白的附屬設定，隨對應功能啟用。

反灰選項可用滑鼠停留查看原因。一般 Excel 仍完整保留模型參數，方便追溯；作圖選項的簡化不會刪除原始資料或舊擬合結果。

## 匯出

- **圖片：** PNG、JPG、PDF、SVG。使用所選資料及該圖型套用的 Figure Template。寬高為實際 cm，DPI 控制點陣輸出。分峰與背景單獨顯示，不自動相加。
- **Excel：** `.xlsx`，含 Summary、Peak parameters、All parameters、Fit settings、Instrument metadata、Fit history、Joint fit metrics。可分別選全部、目前、選取或作圖勾選資料。數值保留為可運算儲存格；自訂名稱及中繼資料存為文字。
- **Origin 資料包：** ZIP，內含全範圍原始 CSV、擬合區間內的數據／總擬合／分峰／背景／殘差、結果 JSON、名稱對照與 `import_origin.py`。解壓後可手動匯入 CSV；腳本需要已授權的 Origin 與相容的 `originpro`。
- **Origin `.opju`：** 程式提供直接匯出入口；同樣需要本 Python 環境安裝相容 `originpro` 與電腦上的 Origin 授權。為避免覆蓋工作，若連線中已有工作頁則拒絕匯出。會建立可編輯的資料與基本線圖，**目前不轉移 Python 作圖樣式**。本環境尚未驗證實際 Origin 自動化。

## 結果的定義與限制

- 預設橫軸 nm，縱軸為儀器 Counts；Counts 不是已校正光子數。
- 能量座標使用 `E = 1239.8419843320026 / wavelength_nm`。**Jacobian 預設關閉**：僅在使用者確認輸入為每 nm 光譜密度後啟用 `I_E = I_lambda * lambda² / hc`。若資料是 Counts/pixel，需要先確定每個像素／波段的量測定義，不能直接認為是 Counts/nm。啟用後的強度標為 converted units，並不代表完成絕對校正。
- 歸一化以完整量測範圍計算，再裁切擬合區間。面積歸一化對含背景的資料也包含該背景；建議比較前確認選項。論文作圖的歸一化與垂直位移只改呈現，不改分析結果。
- `amplitude` 為所用峰形的面積參數；`sigma`、`gamma` 依 lmfit 模型定義。中心參數與數值求得的峰頂位置分別回報，不對稱模型兩者可不同。
- FWHM 以數值方式在擬合範圍內求取。任一半高交點超出範圍時留空並警示。有限區間面積及面積比例，依該區間的**完整模型曲線**積分，包括被遮罩的區間。
- 實測積分使用實際的非等距橫軸；有遮罩時不回報實測積分及重心，避免跨越缺失區間。重心採扣除背景後取非負值的光譜計算，定義與一般原始強度重心不同。
- 擬合使用未加權最小平方法、多組確定性初始值重試；假設獨立、等變異誤差。標準誤為局部協方差估計，並非重複樣品統計。固定、不可識別或無法估算的標準誤留空。第一版尚未提供 bootstrap、Poisson likelihood、誤差權重或完整信賴區間。
- RMSE、R²、RSS 等用於檢查。AIC/BIC 僅適合比較相同資料、範圍、轉換與誤差假設的模型。聯合擬合的 AIC/BIC、自由參數數目與 reduced chi-square 是**整組**指標，儲存於 Joint fit metrics；各光譜不另外虛構獨立值。
- 分峰自動標為 Peak 1、Peak 2，不能僅依分峰結果判定缺陷、激子或相分離。PL 發光峰位置不自動標為材料能隙。
- 單條未校正 PL 不輸出壽命、缺陷密度、PLQY 或 QFLS。功率／溫度依賴物理模型、廣義 Planck 模型、任意自訂峰形與儀器線寬反卷積為後續擴充項目。
- 儀器檔尾 `Temperature (C)` 原樣保存，不自動當成樣品溫度；`Wavelength (nm)` 不自動當成激發波長。
- 內容相同的不同檔名會提示並保留，不會自動刪除。

## 自動復原與測試

有未儲存變更時每分鐘建立復原檔：已命名專案旁的 `.plproj.recovery`；未命名專案儲存於 Windows 使用者的 `%LOCALAPPDATA%\PLStudio\PL Studio\PL_unsaved.recovery`。可透過「開啟專案」選擇復原檔，再另存新專案。此功能不取代手動儲存。

```powershell
.\.venv\Scripts\python.exe -m pip install pytest
.\.venv\Scripts\python.exe -m pytest tests -q
```

測試涵蓋已知參數合成光譜、全部峰形、固定值與關係式、聯合擬合、取消、遮罩、單位轉換、專案完整性、數值 Excel 與四種圖形輸出，以及 Qt 匯入／選線／加峰／批次／聯合流程。原始範例 ZIP 可用時，額外測試六條原始光譜。合成與參考資料的單峰 Gaussian 測試不代表這是材料的最終物理模型。

## 程式結構

- `main.py`：啟動入口。
- `plstudio/data.py`：匯入、座標轉換、專案保存。
- `plstudio/fitting.py`：模型、約束、多初始值、個別與聯合擬合。
- `plstudio/plotting.py`：顯示與圖片輸出。
- `plstudio/exporting.py`：Excel 與 Origin。
- `plstudio/trends.py`：Condition 趨勢數值、單位檢查與多圖輸出。
- `plstudio/trend_ui.py`：Condition 編輯與趨勢控制介面。
- `plstudio/overlay.py`：原始波長／強度與歸一化光譜疊圖。
- `plstudio/figure_style.py`：跨圖型的頁面、軸、刻度、曲線、圖例及物件格式。
- `plstudio/template_ui.py`：獨立 Figure Template 視窗及設定檔。
- `plstudio/gui.py`：桌面 UI、背景工作執行緒與操作流程。

技術依據：[lmfit 模型](https://lmfit.github.io/lmfit-py/builtin_models.html)、[lmfit 約束](https://lmfit.github.io/lmfit-py/constraints.html)、[Matplotlib GUI 嵌入](https://matplotlib.org/stable/gallery/user_interfaces/index.html)、[Origin Python 整合](https://docs.originlab.com/python)。

## 建置 Windows 安裝檔與發佈

維護者步驟請見 [發佈說明](docs/RELEASING.md)。GitHub 網址尚未設定時，軟體仍可使用，但不會發出啟動更新請求。

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements-build.txt
.\.venv\Scripts\python.exe tools/configure_release.py --repository YOUR_NAME/PL-Studio
powershell -ExecutionPolicy Bypass -File tools/build_windows.ps1
```

需要 Inno Setup 6 或以上。輸出為 `release/PL-Studio-Setup.exe`。發佈前請確認公開原始碼的授權條款；本專案尚未選定授權。
